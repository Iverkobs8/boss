using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Text.RegularExpressions;

namespace usersignup
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnregister_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-QI6H2EA\\SQLEXPRESS01;Initial Catalog=userregcs;Integrated Security=True");
            SqlCommand cmd = new SqlCommand(@"INSERT INTO [dbo].[register]
           ([firstname]
           ,[lastname]
           ,[username]
           ,[password])
     VALUES
           ('" + txtfname.Text + "','" + txtlname.Text + "','" + txtuser.Text + "','" + txtpass.Text + "')", con);

            if (txtpass.Text.Length >= 8)
            {

                if (txtpass.Text == txtconfirmpass.Text)
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Registered Successfully");
                }
                else if (txtpass.Text.Length <8 && txtconfirmpass.Text.Length < 8)
                    {
                        MessageBox.Show("Password must be 8 characters long!");
                    }
                else
                {
                    MessageBox.Show("Password unmatched!");
                }
                }
            }
        }
    }