import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Set;
import java.util.HashSet;
import java.util.Arrays;

public class MySetFrame extends JFrame implements ActionListener {
    private JTextArea outputArea;
    private JButton unionButton;
    private JButton intersectionButton;
    private JButton differenceAButton;
    private JButton differenceBButton;
    private JButton subsetButton;

    private Set<Integer> setA;
    private Set<Integer> setB;

    public static void main(String[] args) {
        MySetFrame frame = new MySetFrame();
    }

    public MySetFrame() {
        super("My Frame");
        setLayout(new BorderLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        outputArea = new JTextArea();
        add(outputArea, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(5, 1));

        unionButton = new JButton("Set A union Set B");
        unionButton.addActionListener(this);
        buttonPanel.add(unionButton);

        intersectionButton = new JButton("Set A intersection Set B");
        intersectionButton.addActionListener(this);
        buttonPanel.add(intersectionButton);

        differenceAButton = new JButton("Set A - Set B");
        differenceAButton.addActionListener(this);
        buttonPanel.add(differenceAButton);

        differenceBButton = new JButton("Set B - Set A");
        differenceBButton.addActionListener(this);
        buttonPanel.add(differenceBButton);

        subsetButton = new JButton("Is Set B a subset of Set A?");
        subsetButton.addActionListener(this);
        buttonPanel.add(subsetButton);

        add(buttonPanel, BorderLayout.SOUTH);

        setA = new HashSet<Integer>();
        setB = new HashSet<Integer>();

        String inputA = JOptionPane.showInputDialog("Enter elements of Set A, separated by commas:");
        for (String num : inputA.split(",")) {
            setA.add(Integer.parseInt(num.trim()));
        }

        String inputB = JOptionPane.showInputDialog("Enter elements of Set B, separated by commas:");
        for (String num : inputB.split(",")) {
            setB.add(Integer.parseInt(num.trim()));
        }

        outputArea.append("set A contains: " + setA + "\n");
        outputArea.append("set B contains: " + setB + "\n\n");

        setSize(400, 300);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == unionButton) {
            Set<Integer> union = new HashSet<Integer>(setA);
            union.addAll(setB);
            outputArea.setText("Set A union Set B: " + union);
        } else if (e.getSource() == intersectionButton) {
            Set<Integer> intersection = new HashSet<Integer>(setA);
            intersection.retainAll(setB);
            outputArea.setText("Set A intersection Set B: " + intersection);
        } else if (e.getSource() == differenceAButton) {
            Set<Integer> differenceA = new HashSet<Integer>(setA);
            differenceA.removeAll(setB);
            outputArea.setText("Set A - Set B: " + differenceA);
        } else if (e.getSource() == differenceBButton) {
            Set<Integer> differenceB = new HashSet<Integer>(setB);
            differenceB.removeAll(setA);
            outputArea.setText("Set B - Set A: " + differenceB);
        
        } else if (e.getSource() == subsetButton) {
            boolean isSubset = setA.containsAll(setB);
            if (isSubset) {
                outputArea.setText("Set B is a subset of Set A.");
            } 
            else {
                outputArea.setText("Set B is not a subset of Set A.");
            
        }
        }
        }
        }
        